
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'danyel117',
  applicationName: 'api-serverless-clase',
  appUid: 'mmwPYnHSWhW1FkNqZy',
  orgUid: '69f5faa4-4e11-4ad4-8d93-3be9c13a4362',
  deploymentUid: '541d7edc-2b2a-4da1-ba8c-14f594cfb02d',
  serviceName: 'mi-api-concesionario-serverless',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'mi-api-concesionario-serverless-dev-app', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}